local test = {}

print("damn testin")

function test:test()
  print("damn moore testin!!! B)")
  snot.set_clear_color(1, 1, 1)
end

return test

